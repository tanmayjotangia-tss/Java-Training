package com.tss.advancedmappingapp.entity;

import jakarta.persistence.Entity;

@Entity
@
public class Student {

    private Long id;
    private Integer rollNumber;
    private String name;
}
